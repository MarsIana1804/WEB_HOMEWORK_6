SELECT student_name, subject_name, avg_grad
FROM (
		SELECT student_name, subject_name, avg_grad, ROW_NUMBER() OVER (PARTITION BY subject_name ORDER BY avg_grad DESC) as rwnbr
		FROM (
				SELECT s.name as student_name, sub.name as subject_name, AVG(g.grade) avg_grad
				FROM students s
				INNER JOIN grades g
				  ON s.id = g.student_id
				INNER JOIN subjects sub
				  ON g.subject_id = sub.id
				GROUP BY s.name, sub.name
		)a
	) b
WHERE rwnbr = 1;