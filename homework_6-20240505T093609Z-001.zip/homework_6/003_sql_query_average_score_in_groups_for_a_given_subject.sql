SELECT sub.name as subject_name, 
       gr.name as group_name,
       AVG(g.grade) avg_grad
FROM students s
	INNER JOIN grades g
	  ON s.id = g.student_id
	INNER JOIN subjects sub
	  ON g.subject_id = sub.id
	INNER JOIN groups gr
	  ON s.group_id = gr.id
GROUP BY sub.name, 
		 gr.name
ORDER BY sub.name, 
		 gr.name;