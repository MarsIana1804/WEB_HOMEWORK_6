to do 
Check how to calculate GPA - lecture