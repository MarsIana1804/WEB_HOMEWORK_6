SELECT gr.name as group_name,
       s.name as student_name, 
	   sub.name as subject_name,
	   g.grade
FROM students s
INNER JOIN grades g
  ON s.id = g.student_id
INNER JOIN subjects sub
  ON g.subject_id = sub.id
INNER JOIN groups gr 
  ON s.group_id = gr.id
ORDER BY gr.name, sub.name, s.name;